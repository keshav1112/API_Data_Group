# API_Data_Group
I am fetching data from API and trying to group as per the class then finding section data then showing student data
